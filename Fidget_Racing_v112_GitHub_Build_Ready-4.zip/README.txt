Fidget Racing v112 Android Studio source project

Open this folder in Android Studio and allow Gradle sync.
Build > Build APK(s) for phone testing.
Build > Generate Signed Bundle / APK > Android App Bundle for Google Play.
A Play Store release requires your own signing key and final application ID; do not publish without testing.
The HTML game is embedded at app/src/main/assets/index.html.
This wrapper does not implement Bluetooth multiplayer or Google Play Billing.
Local file WebView storage and audio need testing on actual Android devices.
