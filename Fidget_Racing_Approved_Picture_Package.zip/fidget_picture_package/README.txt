FIDGET RACING - APPROVED CHAT ROOM ARTWORK

Image: assets/fidget_chat_reference.jpg
Resolution: 1536 x 1024

This is the approved visual reference, not a functional UI.
To integrate into the existing Android game, add the image to its assets and implement actual clickable buttons, chat controls and responsive layout separately.
Do not replace Build 32 or its gameplay logic.
