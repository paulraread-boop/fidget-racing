# Fidget Racing — approved Android source

This source wraps the approved HTML game as an offline Android WebView app. Open in Android Studio and build an APK for local testing. For Play Store, configure signing and produce a signed AAB. Multiplayer and in-app purchases must be separately implemented and tested before advertising them.
