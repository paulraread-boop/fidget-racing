from pathlib import Path
p=Path('android-project/app/src/main/assets/index.html')
s=p.read_text()
marker='id="fidget-results-menu-repair"'
if marker in s: raise SystemExit('Already repaired')
patch='''<script id="fidget-results-menu-repair">
(function(){
function goMenu(){if(typeof returnToMenu==='function')returnToMenu();else if(typeof quitRace==='function')quitRace();}
function fix(){
 const overlay=document.getElementById('overlay');if(!overlay||overlay.classList.contains('hidden'))return;
 const card=overlay.querySelector('.card');if(!card)return;
 let back=card.querySelector('#fidgetBackMain');
 if(!back){back=document.createElement('button');back.id='fidgetBackMain';back.className='primary';back.type='button';card.appendChild(back);}
 back.textContent='⌂ BACK TO MAIN MENU';back.onclick=goMenu;
 const buttons=card.querySelectorAll('button');buttons.forEach(b=>{if(/back to race/i.test(b.textContent)){b.textContent='BACK TO MAIN MENU';b.onclick=goMenu;}});
 if(typeof state==='undefined'||state!=='finished'||typeof cars==='undefined'||!cars.length)return;
 let result=card.querySelector('#fidgetFinishPlacement');if(!result){result=document.createElement('div');result.id='fidgetFinishPlacement';result.style.cssText='margin:12px auto;padding:10px;border:1px solid #7ce7ee;border-radius:10px;font-weight:bold';const heading=card.querySelector('h2');if(heading)heading.insertAdjacentElement('afterend',result);else card.prepend(result);}
 const ordered=typeof order==='function'?order():cars.slice().sort((a,b)=>(a.finish??1e9)-(b.finish??1e9));
 const player=cars[playerSlot];const pos=ordered.findIndex(c=>c.i===playerSlot)+1;
 const top=ordered.slice(0,3).map((c,i)=>['1st','2nd','3rd'][i]+': '+(c.i===playerSlot?'YOU':(c.name||'Car #'+(c.i+1))));
 result.textContent=top.join('  |  ')+'  |  YOUR FINISH: '+(pos||'—')+' / '+cars.length;
}
const overlay=document.getElementById('overlay');if(overlay)new MutationObserver(fix).observe(overlay,{childList:true,subtree:false});
document.addEventListener('click',e=>{if(e.target&&e.target.closest('#fidgetBackMain'))goMenu();});
setInterval(()=>{if(typeof state!=='undefined'&&state==='finished')fix();},1500);
})();
</script>'''
s=s.replace('</body>',patch+'</body>')
p.write_text(s)
print('Results and menu repair installed')
